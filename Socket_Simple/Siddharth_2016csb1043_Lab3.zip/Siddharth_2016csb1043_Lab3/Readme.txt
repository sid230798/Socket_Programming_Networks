------------------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 25/1/19

------------------------------------------------------

To Run Code :-

User:Dir$~ gcc server.c -o server
User:Dir$~ gcc client.c -o client

/*Open Two terminals and run codes*/

User:Dir$~ ./server PORT_NO
User:Dir$~ ./client PORT_NO


To check by Telnet Start Server with PORT_NO
User:Dir$~ telnel localhost PORT_NO
----------------------------------------------------------

*Input Message to be sent from Client

*One message will be sent and Recieved from client and echoed to Server

------------------------------------------------------------------

*Not coded for multiple messages due to problem of whether client is closed or not

