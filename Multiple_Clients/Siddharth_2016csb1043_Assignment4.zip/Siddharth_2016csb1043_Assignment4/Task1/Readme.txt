----------------------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 12/2/19

----------------------------------------------------------

To Run Code :- 

Mac@Usr:~/Dir$ gcc server_multi_client.c -o server
Mac@Usr:~/Dir$ gcc client.c -o client

*Open Two Terminals and run :

Mac@Usr:~/Dir$ ./server PORT_NO
Mac@Usr:~/Dir$ ./client PORT_NO
 
----- PORT_NO must be form command line.

-------------------------------------------------------------

-> Open multiple client terminals at same time
-> Input string to be echoed from Client
-> Server returns string recieved from particular to that client only
-> Input "exit" to close client connection   
