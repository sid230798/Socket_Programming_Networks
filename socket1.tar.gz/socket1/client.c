# include<stdio.h>
# include<stdlib.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include<netinet/in.h>
#include<errno.h>
#include<string.h>
#include<arpa/inet.h>
#include <unistd.h>

int main()
{
	int sock, cli;
	struct sockaddr_in server, client;
	unsigned int len;
	char mesg[] = "Hello server";
	int sent;
	if((sock = socket(AF_INET, SOCK_STREAM, 0))== -1)
	{
		perror("Error in client socket");
		exit(-1);
	}
	
	server.sin_family = AF_INET;
	server.sin_port = htons(8800);
	server.sin_addr.s_addr = INADDR_ANY;
	bzero(&server.sin_zero, 8);
	
	len =sizeof(struct sockaddr_in);
	
	 if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) 
	    { 
		printf("\nConnection Failed \n"); 
		return -1; 
	    } 
	    else
	   	 printf("\nConnection build \n"); 
		
	return 0;

}
