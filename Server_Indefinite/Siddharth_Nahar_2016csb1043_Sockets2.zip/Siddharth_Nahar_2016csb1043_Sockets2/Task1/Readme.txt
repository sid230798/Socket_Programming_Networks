----------------------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 5/2/19

----------------------------------------------------------

To Run Code :- 

Mac@Usr:~/Dir$ gcc server.c -o server
Mac@Usr:~/Dir$ gcc client.c -o client

*Open Two Terminals and run :

Mac@Usr:~/Dir$ ./server PORT_NO
Mac@Usr:~/Dir$ ./client PORT_NO
 
----- PORT_NO must be form command line.

-------------------------------------------------------------

-> Input String to be reversed in client terminal
-> Server returns reversed string
-> Input "Bye" to close client connection   
