----------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 7/2/19

----------------------------------------------

To run code and compile :-

Usr:Dir~/$ gcc serverUDP.c -o server
Usr:Dir~/$ gcc clientUDP.c -o client

*Open two terminals and run

Usr:Dir~/$ ./server PORT_NO
Usr:Dir~/$ ./client PORT_NO

*PORT_NO as command line argument
---------------------------------------------

-> Input domain name from client
-> Server returns IP address
-> Input "Bye" to close client connection   
